package com.wisedu.amp.card.cus.newsAnnouncement.common;

/**
 * @ClassName IaInfoEnum
 * @Description //TODO
 * @Date 2021/4/19 14:56
 *@Author jszhang@wisedu
 * @Version 1.0
 **/
public class IaInfo {
public static final String IA_SUCCESS_CODE = "0";
}
